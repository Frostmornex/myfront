<div class="sh-footer-widgets">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <?php dynamic_sidebar( 'footer-widgets1' ); ?>
            </div>
            <div class="col-md-4 col-sm-6">
                <?php dynamic_sidebar( 'footer-widgets2' ); ?>
            </div>
            <div class="col-md-4 col-sm-6">
                <?php dynamic_sidebar( 'footer-widgets3' ); ?>
            </div>
        </div>
    </div>
</div>
