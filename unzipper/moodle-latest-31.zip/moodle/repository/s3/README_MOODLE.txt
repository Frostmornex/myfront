- S3.php -

Amazon S3 PHP Class

Cloned from git://github.com/tpyo/amazon-s3-php-class.git

https://github.com/tpyo/amazon-s3-php-class
http://undesigned.org.za/2007/10/22/amazon-s3-php-class
